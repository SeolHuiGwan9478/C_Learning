#include <stdio.h>

int GCD(int a, int b);
int LCM(int a, int b);

int main(){
	
	int first_number1, first_number2;
	scanf("%d", &first_number1);
	fflush(stdout);
	scanf("%d", &first_number2);
	
	printf("%d", LCM(first_number1, first_number2));
	
	return 0;
}

int GCD(int a, int b){
	int tmp;
	
	if(a < b){
		tmp = a;
		a = b;
		b = tmp;
	}
	while(b != 0){
		tmp = a%b;
		a = b;
		b = tmp;
	}
	return a;
}

int LCM(int a, int b){
	
	int L;
	int GCD2;
	GCD2 = GCD(a, b);
	L = (a/GCD2) * (b/GCD2) * GCD2;
	return L;
}