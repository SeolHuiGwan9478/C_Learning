#include <stdio.h>

int main(){
	int a, b;
	int tmp;
	int Gcd, first_number1, first_number2;
	int L;
	scanf("%d %d", &a, &b);
	
	first_number1 = a;
	first_number2 = b;
	
	if(a < b){
		tmp = a;
		a = b;
		b = tmp;
	}
	while(b != 0){
		tmp = a%b;
		a = b;
		b = tmp;
	}
	
	Gcd = a;
	L = (first_number1/Gcd) * (first_number2/Gcd) * Gcd;
	printf("%d", L);
	return 0;
}