#include <stdio.h>
int arraymax(int n, int a[]){
	int i;
	int max = 0;
	int ind_max = 0;
	for(i=0;i<n;i++)
		if(a[i]>max){
			max = a[i];
			ind_max = i;
		}
	return ind_max;
}	
int main(){
	int A[100] = {0, };
	int n,i;
	int ind_max,temp;
	scanf("%d", &n);
	for(i=0;i<n;i++){
		scanf("%d", &A[i]);
	}	
	
	for(i=n-1;i>0;i--){
		ind_max = arraymax(i+1, A);
		temp = A[ind_max];
		A[ind_max]=A[i];
		A[i] = temp;
		
	}	
	for(i=0;i<n;i++)
		printf("%d", A[i]);
	
	return 0;
}
