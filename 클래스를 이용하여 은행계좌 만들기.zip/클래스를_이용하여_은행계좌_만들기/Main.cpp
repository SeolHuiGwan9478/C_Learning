#include <iostream>
#include <string>
#include <string.h>
#define ini_accountNum 11111
using namespace std;

class BankAccount{
	private:
	int accountNumber;
	string owner;
	int balance;
	int PinNumber;
	
	public:
	BankAccount(){}
	BankAccount(string owner1, int pinNum, int ini_balance);
	BankAccount(string owner1, int pinNum, int ini_balance, int acNum);
	void setOwner(string name);
	string getOwner();
	int getAccountNumber();
	bool checkPinNumber();
	void changePinNumber(int num);
	int getBalance();
	void deposit(int amount);
	void withdraw(int amount);
	void print();
};
BankAccount::BankAccount(string owner1, int pinNum, int ini_balance){
	owner = owner1; //예금주
	balance = ini_balance; //금액
	PinNumber = pinNum; //비밀번호
	accountNumber = ini_accountNum; //계좌번호
}
BankAccount::BankAccount(string owner1, int pinNum, int ini_balance, int acNum){
	owner = owner1;
	balance = ini_balance;
	PinNumber = pinNum;
	accountNumber = acNum;
}
void BankAccount::setOwner(string name){
	owner = name;
}
string BankAccount::getOwner(){
	return owner;
}
bool BankAccount::checkPinNumber(){
	int number;
	cin >> number;
	if(number == PinNumber)
		return true;
	else{
		cout << "PWD not correct";
		return false;
	}
}
void BankAccount::changePinNumber(int num){
	if(checkPinNumber()){
		PinNumber = num;
	}
}
int BankAccount::getAccountNumber(){
	return accountNumber;
}
int BankAccount::getBalance(){
	if(checkPinNumber())
		return balance;
	else
		return -1;
}
void BankAccount::deposit(int amount){
	balance += amount;
}
void BankAccount::withdraw(int amount){
	if(checkPinNumber()){
		if(amount > balance)
			cout << "잔액 부족";
		else
			balance = balance - amount;
	}
}
void BankAccount::print(){
	cout<<"owner : " <<owner<<endl<<"accountnumber"<<accountNumber<<endl<<"balance : "<<balance<<endl;
}
int main() {
	string name;
	int pwd;
	int startbalance;
	int amount;
	int newnum, tmp;
	cin >> name >> pwd >> startbalance;
	BankAccount account01(name, pwd, startbalance);
	int command = 0;
	while(1){
		cin >> command;
		if(command == 1){
			tmp = account01.getBalance();
			if(tmp != -1)
				cout << tmp;
		}
		else if(command == 2){
			cin >> amount;
			account01.deposit(amount);
		}
		else if(command == 3){
			cin >> amount;
			account01.withdraw(amount);
		}
		else if(command == 4){
			cin >> newnum;
			account01.changePinNumber(newnum);
		}
		else if(command == 5){
			break;
		}
		else{
			cout << "error" <<endl;
			continue;
		}
	}
	return 0;
}